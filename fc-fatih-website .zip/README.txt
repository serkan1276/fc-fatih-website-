FC Fatih Ingolstadt e.V. – Website Paket

Dateien:
- index.html (fertige Startseite)
- hausordnung.pdf (deine hochgeladene Hausordnung)
- mietvertrag.pdf (dein Nutzungsvertrag)
- README.txt (diese Anleitung)

Nutzung:
1) Öffne index.html im Browser.
2) Lade den Ordner/ZIP auf euren Webspace hoch (z. B. /htdocs).
3) Ersetze im Bereich NEWS die Links durch eure BFV/FuPa-Teamlinks.
4) Ersetze im Kalender-Abschnitt die iframe src durch euren Google-Kalender-Embed.
5) Sponsoren-Logos als PNG/JPG in denselben Ordner legen und im Abschnitt Partner verlinken.
